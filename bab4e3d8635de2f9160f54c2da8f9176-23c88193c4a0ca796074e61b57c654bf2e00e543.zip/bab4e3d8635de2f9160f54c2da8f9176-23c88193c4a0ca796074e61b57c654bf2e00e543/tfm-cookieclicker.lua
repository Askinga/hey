--http://cookieclicker.wikia.com/wiki/Upgrades
tfm.exec.disableAutoNewGame(true)
tfm.exec.disableAutoShaman(true)
tick=0
timePassed=0
players={}
map=[[<C><P L="1600" /><Z><S><S L="1600" H="48" X="800" Y="380" T="12" P="0,0,0.3,0.2,0,0,0,0" /></S><D><DS Y="345" X="400" /></D><O /><L /></Z></C>]]

img={
	cookie={"168537abe8d",250,250},
	bg="1685384bdc0"
}

settings={
	cookies=0,
	cookiePerClick=1,
	cps=0
}

upgrades={
	--[[ CURSORS ]]--
	reinforcedindexfinger={
		name="Reinforced Index Finger",
		cost=100,
		req=function() return buildings.cursor.owned>=1 end,
		owned=false,
		description="The mouse gains +1 cookie per click. Cursors gain +0.1 base CpS.",
		quote="prod prod",
		effect=function() settings.cookiePerClick=settings.cookieperClick+1 buildings.cursor.cps=buildings.cursor.cps+0.1 end
	},
	carpaltunnelpreventioncream={
		name="Carpal Tunnel Prevention Cream",
		cost=400,
		req=function() return buildings.cursor.owned>=1 end,
		owned=false,
		description="The mouse and cursors are twice as efficient.",
		quote="it... it hurts to click...",
		effect=function() settings.cookiePerClick=settings.cookieperClick*2 buildings.cursor.cps=buildings.cursor.cps*2 end
	},
	ambidextrous={
		name="Ambidextrous",
		cost=10000,
		req=function() return buildings.cursor.owned>=10 end,
		owned=false,
		description="The mouse and cursors are twice as efficient.",
		quote="Look ma, both hands!",
		effect=function() settings.cookiePerClick=settings.cookieperClick*2 buildings.cursor.cps=buildings.cursor.cps*2 end
	},
	thousandfingers={
		name="Thousand Fingers",
		cost=500000,
		req=function() return buildings.cursor.owned>=20 end,
		owned=false,
		description="The mouse and cursors gain +0.1 cookies for each non-cursor object owned.",
		quote="clickity",
		effect=function() buildings.cursor.cpspc=buildings.cursor.cpspc+0.1 settings.cpspc=settings.spspc+0.1 end
	},
	millionfingers={
		name="Million Fingers",
		cost=50000000,
		req=function() return buildings.cursor.owned>=40 end,
		owned=false,
		description="The mouse and cursors gain +0.5 cookies for each non-cursor object owned.",
		quote="clickityclickity",
		effect=function() buildings.cursor.cpspc=buildings.cursor.cpspc+0.5 settings.cpspc=settings.spspc+0.5 end
	},
	billionfingers={
		name="Billion Fingers",
		cost=500000000,
		req=function() return buildings.cursor.owned>=80 end,
		owned=false,
		description="The mouse and cursors gain +2 cookies for each non-cursor object owned.",
		quote="clickityclickityclickity",
		effect=function() buildings.cursor.cpspc=buildings.cursor.cpspc+2 settings.cpspc=settings.spspc+2 end
	},
	trillionfingers={
		name="Trillion Fingers",
		cost=5000000000,
		req=function() return buildings.cursor.owned>=120 end,
		owned=false,
		description="The mouse and cursors gain +10 cookies for each non-cursor object owned.",
		quote="clickityclickityclickityclickity",
		effect=function() buildings.cursor.cpspc=buildings.cursor.cpspc+10 settings.cpspc=settings.spspc+10 end
	},
	quadrillionfingers={
		name="Quadrillion Fingers",
		cost=50000000000,
		req=function() return buildings.cursor.owned>=160 end,
		owned=false,
		description="The mouse and cursors gain +20 cookies for each non-cursor object owned.",
		quote="clickityclickityclickityclickityclick",
		effect=function() buildings.cursor.cpspc=buildings.cursor.cpspc+20 settings.cpspc=settings.spspc+20 end
	},
	quintillionfingers={
		name="Quintillion Fingers",
		cost=50000000000000,
		req=function() return buildings.cursor.owned>=200 end,
		owned=false,
		description="The mouse and cursors gain +100 cookies for each non-cursor object owned.",
		quote="man, just go click click click click click, it�s real easy, man.",
		effect=function() buildings.cursor.cpspc=buildings.cursor.cpspc+100 settings.cpspc=settings.spspc+100 end
	},
	sextillionfingers={
		name="Sextillion Fingers",
		cost=500000000000000,
		req=function() return buildings.cursor.owned>=240 end,
		owned=false,
		description="The mouse and cursors gain another +100 cookies for each non-cursor object owned.",
		quote="sometimes things just click",
		effect=function() buildings.cursor.cpspc=buildings.cursor.cpspc+100 settings.cpspc=settings.spspc+100 end
	},
	--[[ GRANDMAS ]]--
	forwardsfromgrandma={
		name="Forwards from Grandma",
		cost=1000,
		req=function() return buildings.grandma.owned>=1 end,
		owned=false,
		description="Grandmas gain +0.3 base CpS.",
		quote="RE:RE:thought you'd get a kick out of this ;))",
		effect=function() buildings.grandma.cps=buildings.grandma.cps+0.3 end
	},
	steelplatedrollingpins={
		name="Steel-plated Rolling Pins",
		cost=10000,
		req=function() return buildings.grandma.owned>=1 end,
		owned=false,
		description="Grandmas are twice as efficient.",
		quote="Just what you kneaded.",
		effect=function() buildings.grandma.cps=buildings.grandma.cps*2 end
	},
	lubricateddentures={
		name="Lubricated Dentures",
		cost=100000,
		req=function() return buildings.grandma.owned>=10 end,
		owned=false,
		description="Grandmas are twice as efficient.",
		quote="squish",
		effect=function() buildings.grandma.cps=buildings.grandma.cps*2 end
	},
	prunejuice={
		name="Prune Juice",
		cost=1000000,
		req=function() return buildings.grandma.owned>=50 end,
		owned=false,
		description="Grandmas are twice as efficient.",
		quote="Get's me going.",
		effect=function() buildings.grandma.cps=buildings.grandma.cps*2 end
	},
	doublethickglasses={
		name="Double-thick Glasses",
		cost=50000000,
		req=function() return buildings.grandma.owned>=100 end,
		owned=false,
		description="Grandmas are twice as efficient.",
		quote="Oh... so THAT's what I've been baking.",
		effect=function() buildings.grandma.cps=buildings.grandma.cps*2 end
	},
	farmergrandmas={
		name="Farma Grandmas",
		cost=50000,
		req=function() return buildings.farm.owned>=15 end,
		owned=false,
		description="Grandmas are twice as efficient.",
		quote="A nice farmer to grow more cookies.",
		effect=function() buildings.grandma.cps=buildings.grandma.cps*2 end
	},
	workergrandmas={
		name="Worker Grandmas",
		cost=300000,
		req=function() return buildings.factory.owned>=1 end,
		owned=false,
		description="Grandmas are twice as efficient.",
		quote="A nice worker to manufacture more cookies.",
		effect=function() buildings.grandma.cps=buildings.grandma.cps*2 end
	},
	minergrandmas={
		name="Miner Grandmas",
		cost=1000000,
		req=function() return buildings.mine.owned>=15 end,
		owned=false,
		description="Grandmas are twice as efficient.",
		quote="A nice miner to dig more cookies.",
		effect=function() buildings.grandma.cps=buildings.grandma.cps*2 end
	},
	cosmicgrandmas={
		name="Cosmic Grandmas",
		cost=4000000,
		req=function() return buildings.shipment.owned>=15 end,
		owned=false,
		description="Grandmas are twice as efficient.",
		quote="A nice thing to... uh... cookies.",
		effect=function() buildings.grandma.cps=buildings.grandma.cps*2 end
	},
	transmutedgrandmas={
		name="Transmuted Grandmas",
		cost=20000000,
		req=function() return buildings.alchemylab.owned>=15 end,
		owned=false,
		description="Grandmas are twice as efficient.",
		quote="A nice golden grandma to convert into more cookies.",
		effect=function() buildings.grandma.cps=buildings.grandma.cps*2 end
	},
	alteredgrandmas={
		name="Altered Grandmas",
		cost=166666600,
		req=function() return buildings.portal.owned>=15 end,
		owned=false,
		description="Grandmas are twice as efficient.",
		quote="a NiCe GrAnDmA tO bA##########",
		effect=function() buildings.grandma.cps=buildings.grandma.cps*2 end
	},
	grandmasgrandmas={
		name="Grandmas' Grandmas",
		cost=12345678900,
		req=function() return buildings.timemachine.owned>=15 end,
		owned=false,
		description="Grandmas are twice as efficient.",
		quote="A nice grandma's nice grandma to bake double the cookies.",
		effect=function() buildings.grandma.cps=buildings.grandma.cps*2 end
	},
	antigrandmas={
		name="Antigrandmas",
		cost=399999999900,
		req=function() return buildings.antimattercondenser.owned>=15 end,
		owned=false,
		description="Grandmas are twice as efficient.",
		quote="A mean antigrandma to vomit more cookies. (Do not put in contact with normal grandmas; loss of matter may occur.)",
		effect=function() buildings.grandma.cps=buildings.grandma.cps*2 end
	},
	--[[ FARMS ]]--
	cheaphoes={
		name="Cheap Hoes",
		cost=5000,
		req=function() return buildings.farm.owned>=5000 end,
		owned=false,
		description="Farms gain +1 base CpS.",
		quote="Rake in the dough!",
		effect=function() end
	},
	fertilizer={
		name="Fertilizer",
		cost=50000,
		req=function() return buildings.farm.owned>=1 end,
		owned=false,
		description="Farms are twice as efficient.",
		quote="It's chocolate, I swear.",
		effect=function() end
	},
	cookietrees={
		name="Cookie Trees",
		cost=500000,
		req=function() return buildings.farm.owned>=10 end,
		owned=false,
		description="Farms are twice as efficient.",
		quote="A relative of the breadfruit.",
		effect=function() end
	},
	geneticallymodifiedcookies={
		name="Genetically Modified Cookies",
		cost=25000000,
		req=function() return buildings.farm.owned>=50 end,
		owned=false,
		description="Farms are twice as efficient.",
		quote="All-natural mutations.",
		effect=function() end
	},
	gingerbreadscarecrows={
		name="Gingerbread Scarecrows",
		cost=500000000,
		req=function() return buildings.farm.owned>=100 end,
		owned=false,
		description="Farms are twice as efficient.",
		quote="Staring at your crops with mischievous glee.",
		effect=function() end
	},
	--[[ FACTORIES ]]--
	sturdierconveyorbelts={
		name="Sturdier Conveyor Belts",
		cost=30000,
		req=function() return buildings.factory.owned>=1 end,
		owned=false,
		description="Factories gain +4 base CpS.",
		quote="You're going places.",
		effect=function() end
	},
	childlabor={
		name="Child Labor",
		cost=300000,
		req=function() return buildings.factory.owned>=1 end,
		owned=false,
		description="Factories are twice as efficient.",
		quote="Cheaper, healthier workforce.",
		effect=function() end
	},
	sweatshop={
		name="Sweatshop",
		cost=3000000,
		req=function() return buildings.factory.owned>=10 end,
		owned=false,
		description="Factories are twice as efficient.",
		quote="Slackers will be terminated.",
		effect=function() end
	},
	radiumreactors={
		name="Radium Reactors",
		cost=150000000,
		req=function() return buildings.factory.owned>=50 end,
		owned=false,
		description="Factories are twice as efficient.",
		quote="Gives your cookies a healthy glow.",
		effect=function() end
	},
	recombobulators={
		name="Recombobulators",
		cost=3000000000,
		req=function() return buildings.factory.owned>=100 end,
		owned=false,
		description="Factories are twice as efficient.",
		quote="A major part of cookie recombobulation.",
		effect=function() end
	},
	--[[ MINES ]]--
	sugargas={
		name="Sugar Gas",
		cost=100000,
		req=function() return buildings.mine.owned>=1 end,
		owned=false,
		description="Mines gain +10 base CpS.",
		quote="A cheap, volatile gas, found in the depths of some chocolate caves.",
		effect=function() end
	},
	megadrill={
		name="Megadrill",
		cost=1000000,
		req=function() return buildings.mine.owned>=1 end,
		owned=false,
		description="Mines are twice as efficient.",
		quote="You're in deep.",
		effect=function() end
	},
	ultradrill={
		name="Ultradrill",
		cost=10000000,
		req=function() return buildings.mine.owned>=10 end,
		owned=false,
		description="Mines are twice as efficient.",
		quote="Finally caved in?",
		effect=function() end
	},
	ultimadrill={
		name="Ultimadrill",
		cost=500000000,
		req=function() return buildings.mine.owned>=50 end,
		owned=false,
		description="Mines are twice as efficient.",
		quote="Pierce the heavens, etc.",
		effect=function() end
	},
	hbombmining={
		name="H-Bomb Mining",
		cost=10000000000,
		req=function() return buildings.mine.owned>=100 end,
		owned=false,
		description="Mines are twice as efficient.",
		quote="Questionable efficiency, but spectacular nonetheless.",
		effect=function() end
	},
	--[[ SHIPMENTS ]]--
	n={
		name="",
		cost=0,
		req=function() return buildings.grandma.owned>=1 end,
		owned=false,
		description="Grandmas are twice as efficient.",
		quote="",
		effect=function() end
	},
	n={
		name="",
		cost=0,
		req=function() return buildings.grandma.owned>=1 end,
		owned=false,
		description="Grandmas are twice as efficient.",
		quote="",
		effect=function() end
	},
	n={
		name="",
		cost=0,
		req=function() return buildings.grandma.owned>=1 end,
		owned=false,
		description="Grandmas are twice as efficient.",
		quote="",
		effect=function() end
	},
	n={
		name="",
		cost=0,
		req=function() return buildings.grandma.owned>=1 end,
		owned=false,
		description="Grandmas are twice as efficient.",
		quote="",
		effect=function() end
	},
	n={
		name="",
		cost=0,
		req=function() return buildings.grandma.owned>=1 end,
		owned=false,
		description="Grandmas are twice as efficient.",
		quote="",
		effect=function() end
	},
	n={
		name="",
		cost=0,
		req=function() return buildings.grandma.owned>=1 end,
		owned=false,
		description="Grandmas are twice as efficient.",
		quote="",
		effect=function() end
	},
	n={
		name="",
		cost=0,
		req=function() return buildings.grandma.owned>=1 end,
		owned=false,
		description="Grandmas are twice as efficient.",
		quote="",
		effect=function() end
	},
	n={
		name="",
		cost=0,
		req=function() return buildings.grandma.owned>=1 end,
		owned=false,
		description="Grandmas are twice as efficient.",
		quote="",
		effect=function() end
	},
	n={
		name="",
		cost=0,
		req=function() return buildings.grandma.owned>=1 end,
		owned=false,
		description="Grandmas are twice as efficient.",
		quote="",
		effect=function() end
	},
	--[[
	n={
		name="",
		cost=0,
		req=function() return buildings.grandma.owned>=1 end,
		owned=false,
		description="Grandmas are twice as efficient.",
		quote="",
		effect=function() end
	},
	]]
}
                                                                               

buildings={
	cursor={
		name="Cursor",
		icon="16853843bef",
		id=1,
		cost=15,
		owned=0,
		cps=0.1,
		description="Autoclicks once every 10 seconds"
	},
	grandma={
		name="Grandma",
		icon="16853839088",
		id=2,
		cost=100,
		owned=0,
		cps=0.5,
		description="A nice grandma to bake more cookies."
	},
	farm={
		name="Farm",
		icon="1685383b046",
		id=3,
		cost=500,
		owned=0,
		cps=4,
		description="Grows cookie plants from cookie seeds."
	},
	factory={
		name="Factory",
		icon="16853842535",
		id=4,
		cost=3000,
		owned=0,
		cps=10,
		description="Produces large quantities of cookies."
	},
	mine={
		name="Mine",
		icon="1685383756a",
		id=5,
		cost=10000,
		owned=0,
		cps=40,
		description="Mines out cookie dough and chocolate chips."
	},
	shipment={
		name="Shipment",
		icon="1685383363d",
		id=6,
		cost=40000,
		owned=0,
		cps=100,
		description="Brings in fresh cookies from the cookie planet."
	},
	alchemylab={
		name="Alchemy Lab",
		icon="1685384ef4d",
		id=7,
		cost=200000,
		owned=0,
		cps=400,
		description="Turns gold into cookies!"
	},
	portal={
		name="Portal",
		icon="168538351ce",
		id=8,
		cost=1666666,
		owned=0,
		cps=6666,
		description="Opens a door to the cookieverse."
	},
	timemachine={
		name="Time Machine",
		icon="1685387eb14",
		id=9,
		cost=123456789,
		owned=0,
		cps=98765,
		description="Brings cookies from the past, before they were even eaten."
	},
	antimattercondenser={
		name="Antimatter Condenser",
		icon="1685384d618",
		id=10,
		cost=3999999999,
		owned=0,
		cps=999999,
		description="Condenses the antimatter in the universe into cookies."
	}
}

eventLog={
	"<i>A new round has just started. Get clicking!</i>",
	"_________________________________________"
}

function eventNewPlayer(name)
	tfm.exec.respawnPlayer(name)
	system.bindMouse(name,true)
	tfm.exec.addImage(img.bg..".png","?0",0,0)
	tfm.exec.addImage(img.cookie[1]..".png","_100",150-(img.cookie[2]/2),220-(img.cookie[2]/2))
	ui.addTextArea(0,"<p align='center'><font size='32' face='Soopafresh,Verdana'>"..settings.cookies.."</font></p>",nil,5,30,305,46,nil,nil,0.5)
	ui.addTextArea(1,"<font size='10'>"..table.concat(eventLog,"\n").."</font>",nil,1350,20,500,200,0x000000,0xFFFFFF,0)
	showShop()
	players[name]={voted={},votes=0}
end

function newRound()
	tfm.exec.newGame(map)
	tick=0
	settings.cookies=0
	updateInfo()
	for name,player in pairs(tfm.get.room.playerList) do
		eventNewPlayer(name)
	end
end

function eventMouse(name,x,y)
	if pythag(x,y,65,150,220,65) then
		settings.cookies=settings.cookies+settings.cookiePerClick
		tfm.exec.displayParticle(15,x,y,0,-0.5,0,0)
		--updateInfo()
	end
end

function updateInfo()
	tfm.exec.setUIMapName("Cookies: "..cval(math.floor(settings.cookies)).." | CPS: "..cval(settings.cps).." | Time Passed: "..timePassed.."<")
	ui.updateTextArea(0,"<p align='center'><font size='32' face='Soopafresh,Verdana'>"..cval(math.floor(settings.cookies)).."</font></p>",nil)
end

function buyBuilding(building,name)
	if settings.cookies>=buildings[building].cost then
		settings.cookies=math.floor(settings.cookies-buildings[building].cost)
		updateLog(name.." got a "..buildings[building].name.." for "..buildings[building].cost.." cookies.")
		buildings[building].cost=math.floor(buildings[building].cost+(buildings[building].cost/100*15))
		buildings[building].owned=buildings[building].owned+1
		ui.updateTextArea(-buildings[building].id,buildingMenu(building),nil)
	end
end

function buildingMenu(building)
	local b=buildings[building]
	local text="<font size='10'><b>"..b.name.."</b>   "..
		"<a href='event:buy "..building.."'>[Buy]</a>   "..
		"Owned: "..b.owned.." | "..
		"CPS: "..b.cps.." | "..
		"Cost: "..cval(b.cost).."\n"..
		b.description.."\n</font>"
	return text
end

function buyBuilding(building,name)
	if settings.cookies>=buildings[building].cost then
		settings.cookies=math.floor(settings.cookies-buildings[building].cost)
		updateLog(name.." got a "..buildings[building].name.." for "..buildings[building].cost.." cookies.")
		buildings[building].cost=math.floor(buildings[building].cost+(buildings[building].cost/100*15))
		buildings[building].owned=buildings[building].owned+1
		ui.updateTextArea(-buildings[building].id,buildingMenu(building),nil)
	end
end

function upgradeMenu(id)
	local u=upgrades[id]
	local text="<font size='10'><b>"..u.name.."</b>   "..
		"<a href='event:buy "..id.."'>[Buy]</a>   "..
		"Cost: "..u.cost.."\n"..
		u.description.."\n</font>"
	return text
end

function eventTextAreaCallback(id,name,callback)
	eventChatCommand(name,callback)
end

function displayBuilding(building,x,y,i)
	ui.addTextArea(-buildings[building].id,buildingMenu(building),nil,x,y,400,32,0x000000,0xFFFFFF,0.5)
	tfm.exec.addImage(buildings[building].icon..".png","!"..buildings[building].id,x-70,y-26)
end

function showShop()
	local i=0
	local k=1
	for building,tbl in pairs(buildings) do
		if i/5==1 then
			k=k+1
			i=0
		end
		displayBuilding(building,-50+(k*479),30+(i*60))
		i=i+1
	end
end

function updateLog(text)
	table.insert(eventLog,text)
	if #eventLog>15 then
		table.remove(eventLog,1)
	end
	ui.updateTextArea(1,"<font size='10'>"..table.concat(eventLog,"\n").."</font>",nil)
end

function cps()
	local persec=0
	for building,tbl in pairs(buildings) do
		persec=persec+(tbl.owned*tbl.cps)
	end
	settings.cookies=math.floor(settings.cookies+persec)
	settings.cps=persec
end

function table.concat(tbl,delim)
	local str=''
	if delim==nil then delim='' end
	for k,v in pairs(tbl) do
		str=str..v..delim
	end
	return str
end

function cval(amount)
	local formatted = amount
	while true do  
		formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')
		if (k==0) then
			break
		end
	end
	return formatted
end

function eventLoop(time,remaining)
	tick=tick+1
	if tick==2 then
		tick=0
		cps()
		timePassed=math.floor(time/1000)
	end
	updateInfo()
end

for i,command in ipairs({"buy","cookies","cps","ban"}) do
	system.disableChatCommandDisplay(command,true)
end

function eventChatCommand(name,command)
	local split=string.find(command," ") or #command+1
	local cmd=string.sub(command,1,split-1)
	local args=string.sub(command,split+1)
	local arg={}
	for argument in args:gmatch("[^%s]+") do
		table.insert(arg,argument)
	end
	if not players[name].banned then
		if cmd=="buy" and arg[1] then
			if buildings[arg[1]] then
				buyBuilding(arg[1],name)
			end
		elseif cmd=="cookies" and tonumber(arg[1]) then
			settings.cookies=tonumber(arg[1])
		elseif cmd=="cps" and tonumber(arg[1]) then
			settings.cps=tonumber(arg[1])
		end
	end
	if players[name].voted~={} and cmd=="ban" and arg[1] then
		if tfm.get.room.playerList[upper(arg[1])] and not players[upper(arg[1])].banned then
			players[name].voted[upper(arg[1])]=true
			players[upper(arg[1])].votes=players[upper(arg[1])].votes+1
			local i=0
			for n in pairs(tfm.get.room.playerList) do
				i=i+1
			end
			if players[upper(arg[1])].votes>=(i/2) then
				players[upper(arg[1])].banned=true
				print(upper(arg[1]).." has been banned.")
			end
		end
	end
end

function upper(str)
	return (str:gsub("^%l", string.upper))
end

function pythag(x1,y1,r1,x2,y2,r2)
	local x=x2-x1
	local y=y2-y1
	local r=r2+r1
	return x*x+y*y<r*r
end

newRound()